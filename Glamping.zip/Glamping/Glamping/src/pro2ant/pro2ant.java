/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pro2ant;
import koneksi.koneksi;
/**
 *
 * @author Microsoft
 */
public class pro2ant {
     public static void main(String[] args) {
        // Contoh: memanggil koneksi
        koneksi db = new koneksi();
        db.connect(); // Sesuai contoh dosen kamu
    }
}


