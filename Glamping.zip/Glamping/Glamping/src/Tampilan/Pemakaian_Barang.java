/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Tampilan;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;
import java.sql.Statement;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

/**
 *
 * @author Microsoft
 */
public class Pemakaian_Barang extends javax.swing.JFrame {
            Connection conn;
            Statement stm;
    /**
     * Creates new form Pemakaian_Barang
     */
    public Pemakaian_Barang() {
        initComponents();
         //panggil koneksi
       koneksi koneksi = new koneksi();
       this.conn = koneksi.connect();
       
        try {
            stm = conn.createStatement(); // sukses kalau conn tidak null
        } catch (Exception e) {
            System.out.println("Gagal membuat statement: " + e.getMessage());
        }
            // tampilkanData();
             
  txtid.addKeyListener(new java.awt.event.KeyAdapter() {
    public void keyReleased(java.awt.event.KeyEvent evt) {
        cariNamaBarang();
    }
});

}
    // Tambahkan setelah constructor FormPemakaianBarang()
private void cariNamaBarang() {
    String id_Barang = txtid.getText();

    try {
        String sql = "SELECT nama_barang FROM barang WHERE Id_Barang = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, id_Barang);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            txtnamabarang.setText(rs.getString("nama_barang"));
        } else {
            txtnamabarang.setText("");
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Gagal mengambil data barang: " + ex.getMessage());
    }
}

 private boolean isEditMode = false;

    public void setEditMode(boolean editMode) {
        this.isEditMode = editMode;
    }
    
    public void setData( String IdPemakaian, String Id_Barang, String NamaBarang, String TanggalPemakaian, String JumlahDigunakan, String DigunakanOleh) {
            txtid.setText(Id_Barang);
            txtnamabarang.setText(NamaBarang);
            try {
        java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse(TanggalPemakaian);
        txtjcalender.setDate(date);
        
    } catch (ParseException e) {
        JOptionPane.showMessageDialog(null, "Format tanggal salah: " + e.getMessage());
    }
            txtjumlah.setText(JumlahDigunakan);
            txtdigunakan.setText(DigunakanOleh);
            txtid.setEnabled(false); // Tidak boleh ubah ID saat edit
    }
//public void tampilkanData() {
//    // Membuat model tabel baru
//    DefaultTableModel model = new DefaultTableModel();
//    
//    // Menambahkan kolom
//    model.addColumn("IdPemakaian");
//    model.addColumn("Id_Barang");
//    model.addColumn("NamaBarang");
//    model.addColumn("TanggalPemakaian");
//    model.addColumn("Jumlah");
//    model.addColumn("DigunakanOleh");
//
//    // Set model ke tabel
//    TabelPemakaian.setModel(model);
//
//    // Ambil data dari database
//    try {
//        String sql = "SELECT p.*, b.NamaBarang FROM pemakaianbarang p JOIN barang b ON p.Id_Barang = b.Id_Barang";
//        Statement st = conn.createStatement();
//        ResultSet rs = st.executeQuery(sql);
//        
//        // Loop baris hasil query
//        while (rs.next()) {
//            Object[] row = {
//                rs.getString("Id_Barang"),
//                rs.getString("NamaBarang"),
//                rs.getString("tanggalPemakaian"),
//                rs.getString("Jumlah"),
//                rs.getString("DigunakanOleh")
//            };
//            model.addRow(row);
//        }
//    } catch (Exception e) {
//        JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
//    }
//}
//
//
//void TabelpemakaianMouseClicked(java.awt.event.MouseEvent evt){
//    
//    int baris = TabelPemakaian.getSelectedRow();
//    if (baris != -1) {
//        String Id_Barang = TabelPemakaian.getValueAt(baris, 0).toString();
//        String NamaBarang = TabelPemakaian.getValueAt(baris, 0).toString();
//        String TanggalPemakaian = TabelPemakaian.getValueAt(baris, 1).toString();
//        String Jumlah = TabelPemakaian.getValueAt(baris, 2).toString();
//        String DigunakanOleh = TabelPemakaian.getValueAt(baris, 3).toString();
//
//        txtid.setText(Id_Barang);
//        
//        // Konversi tanggal string ke Date lalu set ke JDateChooser
//        try {
//            java.util.Date tanggal = new SimpleDateFormat("yyyy-MM-dd").parse(TanggalPemakaian);
//            txtjcalender.setDate(tanggal);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        txtjumlah.setText(Jumlah);
//        txtdigunakan.setText(DigunakanOleh);
//    }
//}

private void bersihkanTextbox() {
    txtid.setText("");
    txtnamabarang.setText("");
    txtjcalender.setDate(null); // Ini untuk JDateChooser atau JCalendar
    txtjumlah.setText("");
    txtdigunakan.setText("");
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtdigunakan = new javax.swing.JTextField();
        txtjumlah = new javax.swing.JTextField();
        txtid = new javax.swing.JTextField();
        txtnamabarang = new javax.swing.JTextField();
        btnbatal = new javax.swing.JButton();
        btnsimpan = new javax.swing.JButton();
        txtjcalender = new com.toedter.calendar.JDateChooser();
        jLabel7 = new javax.swing.JLabel();
        btnbersihkan = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel1.setText("TAMBAH PEMAKAIAN BARANG");

        jLabel3.setText("Tanggal");

        jLabel4.setText("Nama Barang");

        jLabel5.setText("Jumlah  Digunakan");

        jLabel6.setText("Digunakan Oleh");

        txtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidActionPerformed(evt);
            }
        });

        txtnamabarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnamabarangActionPerformed(evt);
            }
        });

        btnbatal.setText("Batal");
        btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbatalActionPerformed(evt);
            }
        });

        btnsimpan.setText("Simpan");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });

        jLabel7.setText(" ID Barang");

        btnbersihkan.setText("Bersihkan");
        btnbersihkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbersihkanActionPerformed(evt);
            }
        });

        btnhapus.setText("Hapus");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5))
                        .addGap(0, 48, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnsimpan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnhapus)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnbersihkan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnbatal))
                    .addComponent(txtid)
                    .addComponent(txtnamabarang)
                    .addComponent(txtjcalender, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                    .addComponent(txtjumlah)
                    .addComponent(txtdigunakan)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnamabarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtjcalender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtjumlah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtdigunakan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnsimpan)
                    .addComponent(btnbatal)
                    .addComponent(btnbersihkan)
                    .addComponent(btnhapus))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(84, 84, 84))
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(76, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbatalActionPerformed
        // BUTTON KELUAR
        int pilihan = JOptionPane.showConfirmDialog(null, "Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", JOptionPane.YES_NO_OPTION);
        if (pilihan == JOptionPane.YES_OPTION) {
            System.exit(0); // Menutup aplikasi jika pengguna memilih "Yes"
        } 
    }//GEN-LAST:event_btnbatalActionPerformed

    private void txtnamabarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnamabarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnamabarangActionPerformed

    private void txtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
          // BUTOON HAPUS                                      
    String Id_Barang= txtid.getText();    
    if (Id_Barang.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Masukkan ID BARANG untuk menghapus data.");
        return;
    }
    // Query SQL untuk menghapus data berdasarkan NIM
    String sql = "DELETE FROM pemakaianbarang WHERE Id_Barang = ?";
    try {
            PreparedStatement stmt = conn.prepareStatement(sql);
             stmt.setString(1, Id_Barang);
        // Eksekusi query
        int rowsDeleted = stmt.executeUpdate();
        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
            bersihkanTextbox(); // Bersihkan textbox setelah hapus
            //tampilkanData();    // Tampilkan data terupdate di tabel
        } else {
            JOptionPane.showMessageDialog(null, "Data dengan id Barang " + Id_Barang+ " tidak ditemukan.");
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
    }
    }//GEN-LAST:event_btnhapusActionPerformed

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        // BUTTON SIMPAN
    try {
        String sql = "INSERT INTO pemakaianbarang (Id_Barang, TanggalPemakaian, Jumlah DigunakanOleh) VALUES (?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);

        pst.setString(1, txtid.getText());

        // Konversi tanggal dari JDateChooser ke format SQL
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tanggal = sdf.format(txtjcalender.getDate());
        pst.setString(2, tanggal);

        pst.setString(3, txtjumlah.getText());
        pst.setString(4, txtdigunakan.getText());

        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Data pemakaian berhasil disimpan.");
       // tampilkanData();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Gagal menambahkan data: " + ex.getMessage());
    }
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void btnbersihkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbersihkanActionPerformed
         // BUTTON BERSIHKAN
             bersihkanTextbox();
    }//GEN-LAST:event_btnbersihkanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pemakaian_Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pemakaian_Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pemakaian_Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pemakaian_Barang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pemakaian_Barang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbatal;
    private javax.swing.JButton btnbersihkan;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnsimpan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtdigunakan;
    private javax.swing.JTextField txtid;
    private com.toedter.calendar.JDateChooser txtjcalender;
    private javax.swing.JTextField txtjumlah;
    private javax.swing.JTextField txtnamabarang;
    // End of variables declaration//GEN-END:variables
}