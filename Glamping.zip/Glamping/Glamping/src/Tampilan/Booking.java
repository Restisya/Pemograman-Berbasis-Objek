/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Tampilan;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import koneksi.koneksi;

public class Booking extends javax.swing.JFrame {
    Connection conn;

    public Booking() {
        initComponents();
        koneksi koneksi1 = new koneksi();
        conn = koneksi1.connect();
        loadKamarToComboBox();
        loadPelangganToComboBox();
    }

    //untuk refres data
    private Runnable onDataSaved;
    public void setOnDataSaved(Runnable callback) {
        this.onDataSaved = callback;
    }
    //untuk tombol simpan nantinya, edit atau tambah data
    private boolean isEditMode = false;
    public void setEditMode(boolean editMode) {
        this.isEditMode = editMode;
    }

    public class ComboItem {
        private String id;
        private String label;
        public ComboItem(String id, String label) {
            this.id = id;
            this.label = label;
        }
        public String getId() {
            return id;
        }
        @Override
        public String toString() {
            return label;
        }
    }

    public void loadKamarToComboBox() {
        pilihKamar.removeAllItems();
        try {
            String sql = "SELECT IdKamar, JenisKamar FROM kamar";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                pilihKamar.addItem(new ComboItem(rs.getString("IdKamar"), rs.getString("JenisKamar")));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat kamar: " + e.getMessage());
        }
    }

    public void loadPelangganToComboBox() {
        pilihPelanggan.removeAllItems();
        try {
            String sql = "SELECT IdPelanggan, NamaPelanggan FROM pelanggan";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                pilihPelanggan.addItem(new ComboItem(rs.getString("IdPelanggan"), rs.getString("NamaPelanggan")));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat pelanggan: " + e.getMessage());
        }
    }

    //mengisi data dari tabel ke form
    public void setData(String id, String kamarId, String tglbooking, String tglcheckin, String tglcheckout, String pelangganId) {
        txtId.setText(id);
        pilihKamar.setSelectedItem(new ComboItem(kamarId, ""));
        pilihPelanggan.setSelectedItem(new ComboItem(pelangganId, ""));
        txtId.setEnabled(false);
        pilihPelanggan.setEnabled(false);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            pilihBooking.setDate(sdf.parse(tglbooking));
            pilihCheckin.setDate(sdf.parse(tglcheckin));
            pilihCheckout.setDate(sdf.parse(tglcheckout));
        } catch (ParseException e) {
            pilihBooking.setDate(null);
            pilihCheckin.setDate(null);
            pilihCheckout.setDate(null);
        }
    }
    
    //simpan data yang sudah disi dari form ke db
    private void simpanDataBaru() {
        String id = txtId.getText();
        ComboItem kamar = (ComboItem) pilihKamar.getSelectedItem();
        ComboItem pelanggan = (ComboItem) pilihPelanggan.getSelectedItem();

        if (kamar == null || pelanggan == null) {
            JOptionPane.showMessageDialog(this, "Kamar dan pelanggan harus dipilih.");
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tglbooking, tglcheckin, tglcheckout;

        try {
            tglbooking = sdf.format(pilihBooking.getDate());
            tglcheckin = sdf.format(pilihCheckin.getDate());
            tglcheckout = sdf.format(pilihCheckout.getDate());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tanggal belum lengkap atau salah.");
            return;
        }

        try {
            String sql = "INSERT INTO booking (IdBooking, IdKamar, TanggalBooking, TanggalCheckin, TanggalCheckout, IdPelanggan) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, kamar.getId());
            stmt.setString(3, tglbooking);
            stmt.setString(4, tglcheckin);
            stmt.setString(5, tglcheckout);
            stmt.setString(6, pelanggan.getId());

            int result = stmt.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
                dispose();
                if (onDataSaved != null) onDataSaved.run();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan data: " + e.getMessage());
        }
    }
    
    private void updateDataBooking() {
        String id = txtId.getText(); // IdBooking yang akan di-update
        ComboItem kamar = (ComboItem) pilihKamar.getSelectedItem();
        ComboItem pelanggan = (ComboItem) pilihPelanggan.getSelectedItem();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tglbooking, tglcheckin, tglcheckout;

        try {
            tglbooking = sdf.format(pilihBooking.getDate());
            tglcheckin = sdf.format(pilihCheckin.getDate());
            tglcheckout = sdf.format(pilihCheckout.getDate());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tanggal belum lengkap atau salah.");
            return;
        }

        try {
            String sql = "UPDATE booking SET IdKamar = ?, IdPelanggan = ?, TanggalBooking = ?, TanggalCheckin = ?, TanggalCheckout = ? WHERE IdBooking = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, kamar.getId());
            stmt.setString(2, pelanggan.getId());
            stmt.setString(3, tglbooking);
            stmt.setString(4, tglcheckin);
            stmt.setString(5, tglcheckout);
            stmt.setString(6, id); // WHERE IdBooking

            int result = stmt.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Data booking berhasil diperbarui!");
                onDataSaved.run(); // Callback jika ada
                dispose(); // Tutup form
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memperbarui data: " + e.getMessage());
        }
    }

    

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jColorChooser1 = new javax.swing.JColorChooser();
        pilihPelanggan = new javax.swing.JComboBox<>();
        btnSimpan = new javax.swing.JButton();
        btnBatal = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        pilihKamar = new javax.swing.JComboBox<>();
        pilihCheckin = new com.toedter.calendar.JDateChooser();
        pilihBooking = new com.toedter.calendar.JDateChooser();
        pilihCheckout = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        btnBatal.setText("Batal");
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 20)); // NOI18N
        jLabel1.setText("PENGELOLAAN DATA BOOKING");

        jLabel2.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel2.setText("ID BOOKING");

        jLabel3.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel3.setText("TGL. BOOKING");

        jLabel4.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel4.setText("TGL.CHECKIN");

        jLabel5.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel5.setText("TGL.CHECKOUT");

        jLabel7.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel7.setText("ID KAMAR");

        jLabel6.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel6.setText("NAMA PELANGGAN");

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBatal))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(107, 107, 107)
                                .addComponent(btnSimpan)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(pilihBooking, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pilihCheckin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pilihCheckout, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pilihKamar, 0, 129, Short.MAX_VALUE)
                            .addComponent(pilihPelanggan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(109, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(pilihPelanggan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pilihKamar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pilihBooking, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pilihCheckin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(pilihCheckout, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBatal)
                    .addComponent(btnSimpan))
                .addContainerGap(104, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        if (isEditMode) { //jika isEditMode TRUE 
            updateDataBooking(); //maka jalankan fungsi updateData
        } else {
            simpanDataBaru();//jika isEditMode FALSE jalankan method simpanDataBaru
        }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBatalActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Booking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnSimpan;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JColorChooser jColorChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private com.toedter.calendar.JDateChooser pilihBooking;
    private com.toedter.calendar.JDateChooser pilihCheckin;
    private com.toedter.calendar.JDateChooser pilihCheckout;
    private javax.swing.JComboBox<ComboItem> pilihKamar;
    private javax.swing.JComboBox<ComboItem> pilihPelanggan;
    private javax.swing.JTextField txtId;
    // End of variables declaration//GEN-END:variables
}
