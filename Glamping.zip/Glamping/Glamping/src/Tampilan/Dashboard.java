package Tampilan;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;

import Tampilan.Customer;
import Tampilan.Booking;
import Tampilan.room;
import Tampilan.Payment;
import Tampilan.Data_Barang;
import Tampilan.Supplier;
import Tampilan.Pemakaian_Barang;
import Tampilan.PO;



public class Dashboard extends JFrame {
    Connection conn;
    
    private JPanel mainPanel;
    private JPanel sidebarPanel;
    private JPanel contentPanel;
    private Color primaryColor = new Color(70, 130, 180);
    private Color sidebarColor = new Color(231, 228, 223);
    private Color backgroundColor = new Color(255, 255, 255);
    private JTable table; 
    private room roomForm; 
    private Dashboard dashboardRef; 




    public Dashboard() {
        initializeFrame();
        createMainPanel();
        createSidebar();
        createDashboardContent();
        setVisible(true);
    }

    private void initializeFrame() {
        setTitle("Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
    }

    private void createMainPanel() {
        // Initialize content panel
        contentPanel = new JPanel();
        contentPanel.setBackground(backgroundColor);
        add(contentPanel, BorderLayout.CENTER);
    }

    private void createSidebar() {
        sidebarPanel = new JPanel();
        sidebarPanel.setBackground(sidebarColor);
        sidebarPanel.setPreferredSize(new Dimension(200, 0));
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));
        sidebarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Menu title
        JLabel menuLabel = new JLabel("MENU");
        menuLabel.setFont(new Font("Arial", Font.BOLD, 16));
        menuLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        menuLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        sidebarPanel.add(menuLabel);

        // Menu items
        String[] menuItems = {
            "DASHBOARD",
            "CHECK IN", 
            "BOOKING",
            "ROOM",
            "PAYMENT",
            "CUSTOMER",
            "DATA_BARANG",
            "PESANAN PEMBELIAN",
            "PEMAKAIAN BARANG",
            "SUPPLIER",
        };

        for (String item : menuItems) {
            JButton menuButton = createMenuButton(item);
            sidebarPanel.add(menuButton);
            sidebarPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        }

        add(sidebarPanel, BorderLayout.WEST);
    }

    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(180, 35));
        button.setPreferredSize(new Dimension(180, 35));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        button.setFont(new Font("Arial", Font.PLAIN, 12));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setFocusPainted(false);

        if (text.equals("DASHBOARD")) {
            button.setBackground(primaryColor);
            button.setForeground(Color.WHITE);
        }
        
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Reset all buttons
                resetMenuButtons();
                // Highlight selected button
                button.setBackground(primaryColor);
                button.setForeground(Color.WHITE);
                // Update content based on selection
                updateContent(text);
            }
        });
        
        return button;
    } 


    private void resetMenuButtons() {
        Component[] components = sidebarPanel.getComponents();
        for (Component comp : components) {
            if (comp instanceof JButton) {
                comp.setBackground(Color.WHITE);
                comp.setForeground(Color.BLACK);
            }
        }
    }

    private void updateContent(String menuName) {
        contentPanel.removeAll();
        
        switch (menuName) {
            case "DASHBOARD":
                createDashboardContent();
                break;
            case "CUSTOMER":
                createCustomerContent();
                break;
            case "ROOM":
                createRoomContent(); 
                break;
           case "PAYMENT":
                createPAYMENTContent(); 
                break;
            case "DATA_BARANG":
                createDATA_BARANGContent(); 
                break;
            case "SUPPLIER":
                createSUPPLIERContent(); 
                break;
            case "PEMAKAIAN BARANG":
                createPEMAKAIANBARANGContent(); 
                break;
            case "PESANAN PEMBELIAN":
                createPESANANPEMBELIANContent(); 
                break;
            case "BOOKING":
                createBookingContent();
                break;
            case "CHECK IN":
                createCheckinContent();
                break;  
        }
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    private void createDashboardContent() {
        contentPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        // ROMANTIC section
        gbc.gridx = 0;
        gbc.gridy = 0;
        contentPanel.add(createRoomSection("ROMANTIC", getRomanticFacilities()), gbc);

        // FAMILY section
        gbc.gridx = 0;
        gbc.gridy = 1;
        contentPanel.add(createRoomSection("FAMILY", getFamilyFacilities()), gbc);

        // FRIEND section
        gbc.gridx = 0;
        gbc.gridy = 2;
        contentPanel.add(createRoomSection("FRIEND", getFriendFacilities()), gbc);
    }
    
    
    private void createCustomerContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("pelanggan");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);

        // Kolom tabel
        String[] columns = {"ID pelanggan", "NamaPelanggan", "Email", "No. Telepon", "Alamat"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable customerTable = new JTable(model);
        customerTable.setFont(new Font("Arial", Font.PLAIN, 12));
        customerTable.setRowHeight(25);
        customerTable.setFillsViewportHeight(true);
        customerTable.setShowHorizontalLines(false);
        customerTable.setShowVerticalLines(false);
        customerTable.setIntercellSpacing(new Dimension(0, 0));
        customerTable.getTableHeader().setReorderingAllowed(false);

        // Ambil data dari database
        try {
            Connection conn = new koneksi().connect();
            String sql = "SELECT * FROM pelanggan";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("Idpelanggan"),
                    rs.getString("NamaPelanggan"),
                    rs.getString("Email"),
                    rs.getString("NoHp"),
                    rs.getString("Alamat")
                };
                model.addRow(row);
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
        JScrollPane scrollPane = new JScrollPane(customerTable);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        JButton addBtn = new JButton("Tambah");
        addBtn.setBackground(new Color(76, 175, 80)); // Hijau
        addBtn.setForeground(Color.WHITE); // Teks putih
        
        JButton editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(33, 150, 243)); // Biru
        editBtn.setForeground(Color.WHITE);
        
        JButton deleteBtn = new JButton("Hapus");
        deleteBtn.setBackground(new Color(244, 67, 54)); // Merah
        deleteBtn.setForeground(Color.WHITE);


        // Aksi tombol Tambah
        addBtn.addActionListener(e -> {
            Customer form = new Customer(); // Asumsikan kamu punya JFrame FormCustomer
            form.setVisible(true);
        });

        editBtn.addActionListener(e -> {
            int selectedRow = customerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            String nama = model.getValueAt(selectedRow, 1).toString();
            String email = model.getValueAt(selectedRow, 2).toString();
            String nohp = model.getValueAt(selectedRow, 3).toString();
            String alamat = model.getValueAt(selectedRow, 4).toString();

            Customer form = new Customer();
            form.setEditMode(true); // mode edit
            form.setData(id, nama, email, nohp, alamat);
            form.setVisible(true);
        });
        
        deleteBtn.addActionListener(e -> {
            int selectedRow = customerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM pelanggan WHERE Idpelanggan = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id);
                    stmt.executeUpdate();
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow); // Hapus dari tabel
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });
        
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
    }
    
        private void loadBookingData(DefaultTableModel model) {
        model.setRowCount(0); // Bersihkan data lama
        try {
            Connection conn = new koneksi().connect();
            //menggunakan join untuk menampilkan namapelanggan dan jenis kamar
            String sql = "SELECT b.IdBooking, k.JenisKamar, b.TanggalBooking, b.TanggalCheckin, b.TanggalCheckout, p.NamaPelanggan " +
                         "FROM booking b " +
                         "JOIN kamar k ON b.IdKamar = k.IdKamar " +
                         "JOIN pelanggan p ON b.IdPelanggan = p.IdPelanggan " +
                         "ORDER BY b.IdBooking ASC";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("IdBooking"),
                    rs.getString("JenisKamar"),
                    rs.getString("TanggalBooking"),
                    rs.getString("TanggalCheckin"),
                    rs.getString("TanggalCheckout"),
                    rs.getString("NamaPelanggan")
                };
                model.addRow(row);
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
    }

    private void createBookingContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("Booking");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);

        String[] columns = {"ID", "Kamar", "Tgl Booking", "Tgl Checkin", "Tgl Checkout", "Pelanggan"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable bookingTable = new JTable(model);
        bookingTable.setFont(new Font("Arial", Font.PLAIN, 12));
        bookingTable.setRowHeight(25);
        bookingTable.setFillsViewportHeight(true);
        bookingTable.setShowHorizontalLines(false);
        bookingTable.setShowVerticalLines(false);
        bookingTable.setIntercellSpacing(new Dimension(0, 0));
        bookingTable.getTableHeader().setReorderingAllowed(false);

        // load data awal
        loadBookingData(model);
        JScrollPane scrollPane = new JScrollPane(bookingTable);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        JButton addBtn = new JButton("Tambah");
        addBtn.setBackground(new Color(76, 175, 80)); // Hijau
        addBtn.setForeground(Color.WHITE); // Teks putih
        
        JButton editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(33, 150, 243)); // Biru
        editBtn.setForeground(Color.WHITE);
        
        JButton deleteBtn = new JButton("Hapus");
        deleteBtn.setBackground(new Color(244, 67, 54)); // Merah
        deleteBtn.setForeground(Color.WHITE);

        // Callback untuk refresh data setelah simpan/edit
        Runnable refreshData = () -> loadBookingData(model);

        //tombol tambah di klik
        addBtn.addActionListener(e -> {
            Booking form = new Booking(); //membuka form
            form.setOnDataSaved(refreshData);  //update table
            form.setVisible(true);
        });
        //tombol edit di klik
        editBtn.addActionListener(e -> {
            int selectedRow = bookingTable.getSelectedRow(); //selectedrow adalah baris yg di pilih
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }
            
            String id = model.getValueAt(selectedRow, 0).toString(); //baris yg dipilih dan kolom ke1 di simpan sebagai id
            String kamar = model.getValueAt(selectedRow, 1).toString(); //baris yg dipilih dan kolom ke2 di simpan sebagai kamar
            String tglbooking = model.getValueAt(selectedRow, 2).toString(); //baris yg dipilih dan kolom ke3 di simpan sebagai tgl booking
            String tglcheckin = model.getValueAt(selectedRow, 3).toString();
            String tglcheckout = model.getValueAt(selectedRow, 4).toString();
            String pelanggan = model.getValueAt(selectedRow, 5).toString();
            
            Booking form = new Booking(); //buka form booking
            form.setEditMode(true); //set editmode menjadi true
            form.setData(id, kamar, tglbooking, tglcheckin, tglcheckout, pelanggan);//panggil method setData di form booking dengan parameter data di tabel
            form.setOnDataSaved(refreshData); // <- panggil refresh setelah simpan edit
            form.setVisible(true);
        });

        deleteBtn.addActionListener(e -> {
            int selectedRow = bookingTable.getSelectedRow(); //selectedrow adalah baris yg di pilih
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();//baris yg dipilih dan kolom ke1 di simpan sebagai id
            //konfirmasi yes or no
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            
            //jika yes
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM booking WHERE IdBooking = ?"; //siapkan query sql
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id); //set idBooking denagn id(dari id baris yang dipilih)
                    stmt.executeUpdate(); //jalankan query
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow);//hapus row di tabel
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);

        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
    }
    
        private void loadCheckinData(DefaultTableModel model) {
        model.setRowCount(0); // Bersihkan data lama
        try {
            Connection conn = new koneksi().connect();
            String sql = "SELECT c.IdCheckIn, p.NamaPelanggan, c.TanggalCheckin, c.TanggalCheckout, c.Payment, c.IdBooking " +
                         "FROM checkin c " +
                         "JOIN pelanggan p ON c.IdPelanggan = p.IdPelanggan";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("IdCheckIn"),
                    rs.getString("NamaPelanggan"), // ditampilkan nama, bukan ID
                    rs.getString("TanggalCheckin"),
                    rs.getString("TanggalCheckout"),
                    rs.getString("Payment"),
                    rs.getString("IdBooking")
                };
                model.addRow(row);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
    }


    private void createCheckinContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("Checkin");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);
        
        String[] columns = {"ID Checkin", "Nama Pelanggan", "TglCheckin", "TglCheckout", "Payment", "Booking"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable customerTable = new JTable(model);
        customerTable.setFont(new Font("Arial", Font.PLAIN, 12));
        customerTable.setRowHeight(25);
        customerTable.setFillsViewportHeight(true);
        customerTable.setShowHorizontalLines(false);
        customerTable.setShowVerticalLines(false);
        customerTable.setIntercellSpacing(new Dimension(0, 0));
        customerTable.getTableHeader().setReorderingAllowed(false);

        // load data awal
        loadCheckinData(model);
        JScrollPane scrollPane = new JScrollPane(customerTable);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        // Tombol Tambah
        JButton addBtn = new JButton("Tambah");
        addBtn.setBackground(new Color(76, 175, 80)); // Hijau
        addBtn.setForeground(Color.WHITE); // Teks putih

        // Tombol Edit
        JButton editBtn = new JButton("Edit");
        editBtn.setBackground(new Color(33, 150, 243)); // Biru
        editBtn.setForeground(Color.WHITE);

        // Tombol Hapus
        JButton deleteBtn = new JButton("Hapus");
        deleteBtn.setBackground(new Color(244, 67, 54)); // Merah
        deleteBtn.setForeground(Color.WHITE);


        // Callback untuk refresh data setelah simpan/edit
        Runnable refreshData = () -> loadCheckinData(model);

        addBtn.addActionListener(e -> {
            checkin form = new checkin();
            form.setOnDataSaved(refreshData); // <- callback diatur di sini
            form.setVisible(true);
        });

        editBtn.addActionListener(e -> {
            int selectedRow = customerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }
     
            String id = model.getValueAt(selectedRow, 0).toString();
            String nama = model.getValueAt(selectedRow, 1).toString();
            String tglcheckin = model.getValueAt(selectedRow, 2).toString();
            String tglcheckout = model.getValueAt(selectedRow, 3).toString();
            String payment = model.getValueAt(selectedRow, 4).toString();
            String idbooking = model.getValueAt(selectedRow, 4).toString();

            checkin form = new checkin();
            form.setEditMode(true);
//            form.setData(id, nama, tglcheckin, tglcheckout, payment, idbooking);
            form.setOnDataSaved(refreshData); // <- panggil refresh setelah simpan edit
            form.setVisible(true);
        });

        deleteBtn.addActionListener(e -> {
            int selectedRow = customerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM checkin WHERE IdCheckin = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id);
                    stmt.executeUpdate();
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);

        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
    }
    
private void createRoomContent() {
    contentPanel.setLayout(new BorderLayout());
    contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

    JLabel titleLabel = new JLabel("Data Kamar");
    titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
    titleLabel.setForeground(primaryColor);

    JPanel titlePanel = new JPanel(new BorderLayout());
    titlePanel.setBackground(backgroundColor);
    titlePanel.add(titleLabel, BorderLayout.WEST);
    contentPanel.add(titlePanel, BorderLayout.NORTH);

    // Inisialisasi tabel global
    String[] columns = {"IdKamar", "JenisKamar", "Harga", "StatusKamar", "Kapasitas"};
    DefaultTableModel model = new DefaultTableModel(columns, 0);
    table = new JTable(model);
    JScrollPane scrollPane = new JScrollPane(table);
    contentPanel.add(scrollPane, BorderLayout.CENTER);

    // Load data pertama kali
    loadData(); // panggil method loadData()
  
    // Panel tombol
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JButton addBtn = new JButton("Tambah");
    JButton editBtn = new JButton("Edit");
    JButton BersihBtn = new JButton("Bersih");
    JButton onOffBtn = new JButton("On/Off");
    
    // Tambah
    addBtn.addActionListener(e -> {
        room form = new room(); 
        form.setVisible(true);
    });

    // Edit
    editBtn.addActionListener(e -> {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
            return;
        }

        String IdKamar = model.getValueAt(selectedRow, 0).toString();
        String jenisKamar = model.getValueAt(selectedRow, 1).toString();
        String harga = model.getValueAt(selectedRow, 2).toString();
        String Status = model.getValueAt(selectedRow, 3).toString();
        String kapasitas = model.getValueAt(selectedRow, 4).toString();

        room form = new room();
        form.setEditMode(true);
        form.setData(jenisKamar, harga, Status, kapasitas);
        form.setVisible(true);
    });
    
    //Bersih
    BersihBtn.addActionListener(e -> {
    if (roomForm != null) {
        roomForm.bersihkanTextbox();
    } else {
        JOptionPane.showMessageDialog(null, "Form belum dibuka.");
    }
});
    
    //ON/OF
onOffBtn.addActionListener(e -> {
    int selectedRow = table.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Pilih data kamar yang ingin diubah statusnya.");
        return;
    }

    String IdKamar = model.getValueAt(selectedRow, 0).toString(); // Asumsikan kolom 0 adalah ID
    String currentStatus = model.getValueAt(selectedRow, 3).toString(); // Asumsikan kolom 3 adalah StatusKamar
    String newStatus;

    if (currentStatus.equalsIgnoreCase("available")) {
        newStatus = "off";
    } else {
        newStatus = "available";
    }

    // Update ke database
    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/nama_database", "username", "password");
        String sql = "UPDATE kamar SET StatusKamar=? WHERE IdKamar=?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, newStatus);
        pst.setString(2, IdKamar);
        pst.executeUpdate();

        pst.close();
        conn.close();

        JOptionPane.showMessageDialog(null, "Status kamar berhasil diubah ke: " + newStatus);

        // Refresh data di tabel
        if (dashboardRef != null) {
            dashboardRef.loadDataKamar(); // Pastikan kamu punya method ini
        }

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Gagal mengubah status kamar: " + ex.getMessage());
    }
});
    
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(BersihBtn);
        buttonPanel.add(onOffBtn);
        
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);


}
  
private void loadData() {
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setRowCount(0); // bersihkan tabel

    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/glamping", "root", "");
        String sql = "SELECT * FROM kamar";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            String idKamar = rs.getString("IdKamar");
            String jenis = rs.getString("JenisKamar");
            String harga = rs.getString("Harga");
            String status = rs.getString("StatusKamar");
            String kapasitas = rs.getString("Kapasitas");

            model.addRow(new Object[]{idKamar, jenis, harga, status, kapasitas});
        }

        rs.close();
        stmt.close();
        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Gagal memuat data: " + e.getMessage());
    }
}
public void loadDataKamar() {
    loadData();
}



private void createPAYMENTContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("Payment");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);

        // Kolom tabel
        String[] columns = {"IdPayment", "IdBooking", "NamaPelanggan", "CheckinTime", "CheckoutTime", "Dendat", "TotalPembayaran", "StatusPembayaran"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable paymentTable = new JTable(model);
        paymentTable .setFont(new Font("Arial", Font.PLAIN, 12));
        paymentTable .setRowHeight(25);
        paymentTable .setFillsViewportHeight(true);
        paymentTable .setShowVerticalLines(false);
        paymentTable .setIntercellSpacing(new Dimension(0, 0));
        paymentTable .getTableHeader().setReorderingAllowed(false);

        // Ambil data dari database
        try {
            Connection conn = new koneksi().connect();
            String sql = "SELECT * FROM payment";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("IdPayment"),
                    rs.getString("IdBooking"),
                    rs.getString("NamaPelanggan"),
                    rs.getString("CheckinTime"),
                    rs.getString("CheckoutTime"),
                    rs.getString("Denda"),
                    rs.getString("TotalPembayaran"),
                    rs.getString("StatusPembayaran"),
                };
                model.addRow(row);
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
        JScrollPane scrollPane = new JScrollPane(paymentTable );

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        JButton addBtn = new JButton("Tambah");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Hapus");

        // Aksi tombol Tambah
        addBtn.addActionListener(e -> {
           Payment form = new Payment(); // Asumsikan kamu punya JFrame FormCustomer
            form.setVisible(true);
        });

        editBtn.addActionListener(e -> {
            int selectedRow = paymentTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }

            String idpayment = model.getValueAt(selectedRow, 0).toString();
            String idbooking = model.getValueAt(selectedRow, 1).toString();
            String namapelanggan = model.getValueAt(selectedRow, 2).toString();
            String checkintime = model.getValueAt(selectedRow, 3).toString();
            String checkouttime= model.getValueAt(selectedRow, 4).toString();
            String denda = model.getValueAt(selectedRow, 5).toString();
            String totalpembayaran = model.getValueAt(selectedRow, 6).toString();
            String statuspembayaran = model.getValueAt(selectedRow, 7).toString();
            
             
            Payment form = new Payment(); 
            form.setEditMode(true); // mode edit
            form.setData(idpayment, idbooking, namapelanggan, checkintime, checkouttime, denda, totalpembayaran, statuspembayaran);
            form.setVisible(true);
        });
        
        deleteBtn.addActionListener(e -> {
            int selectedRow = paymentTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM payment WHERE Idpayment = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id);
                    stmt.executeUpdate();
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow); // Hapus dari tabel
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });
        
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
    }


private void createDATA_BARANGContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("barang");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);

        // Kolom tabel
        String[] columns = {"Id_Barang", "nama_barang"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable BarangTable = new JTable(model);
        BarangTable .setFont(new Font("Arial", Font.PLAIN, 12));
        BarangTable .setRowHeight(25);
        BarangTable .setFillsViewportHeight(true);
        BarangTable .setShowVerticalLines(false);
        BarangTable .setIntercellSpacing(new Dimension(0, 0));
        BarangTable .getTableHeader().setReorderingAllowed(false);

        // Ambil data dari database
        try {
            Connection conn = new koneksi().connect();
            String sql = "SELECT * FROM barang";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("Id_Barang"),
                    rs.getString("nama_barang"),
              
                };
                model.addRow(row);
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
        JScrollPane scrollPane = new JScrollPane(BarangTable );

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        JButton addBtn = new JButton("Tambah");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Hapus");

        // Aksi tombol Tambah
        addBtn.addActionListener(e -> {
         Data_Barang form = new Data_Barang(); 
            form.setVisible(true);
        });

        editBtn.addActionListener(e -> {
            int selectedRow = BarangTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }

            String Id_Barang = model.getValueAt(selectedRow, 0).toString();
            String nama_barang = model.getValueAt(selectedRow, 1).toString();
          
            Data_Barang form = new Data_Barang(); 
            form.setEditMode(true); // mode edit
            form.setData(Id_Barang, nama_barang);
            form.setVisible(true);
        });
        
        deleteBtn.addActionListener(e -> {
            int selectedRow = BarangTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM barang WHERE Id_Barang = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id);
                    stmt.executeUpdate();
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow); // Hapus dari tabel
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });
        
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
}

        

private void createSUPPLIERContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("supplier");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);

        // Kolom tabel
        String[] columns = {"IdSupplier", "NamaSupplier", "NoHp", "Alamat"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable SupplierTable = new JTable(model);
        SupplierTable .setFont(new Font("Arial", Font.PLAIN, 12));
        SupplierTable .setRowHeight(25);
        SupplierTable .setFillsViewportHeight(true);
        SupplierTable .setShowVerticalLines(false);
        SupplierTable .setIntercellSpacing(new Dimension(0, 0));
        SupplierTable .getTableHeader().setReorderingAllowed(false);

        // Ambil data dari database
        try {
            Connection conn = new koneksi().connect();
            String sql = "SELECT * FROM supplier";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("IdSupplier"),
                    rs.getString("NamaBarang"),
                    rs.getString("NoHp"),
                    rs.getString("Alamat"),
                };
                model.addRow(row);
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
        JScrollPane scrollPane = new JScrollPane(SupplierTable );

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        JButton addBtn = new JButton("Tambah");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Hapus");

        // Aksi tombol Tambah
        addBtn.addActionListener(e -> {
          Supplier form = new Supplier(); 
            form.setVisible(true);
        });

        editBtn.addActionListener(e -> {
            int selectedRow = SupplierTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }

            String IdSupplier = model.getValueAt(selectedRow, 0).toString();
            String NamaSupplier = model.getValueAt(selectedRow, 1).toString();
            String NoHp = model.getValueAt(selectedRow, 0).toString();
            String Alamat = model.getValueAt(selectedRow, 1).toString();
           
            
            Supplier form = new Supplier(); 
            form.setEditMode(true); // mode edit
            form.setData(IdSupplier, NamaSupplier, NoHp, Alamat);
            form.setVisible(true);
        });
        
        deleteBtn.addActionListener(e -> {
            int selectedRow = SupplierTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM barang WHERE Id_Supplier = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id);
                    stmt.executeUpdate();
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow); // Hapus dari tabel
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });
        
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
}

private void createPEMAKAIANBARANGContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("pemakaianbarang");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);

        // Kolom tabel
        String[] columns = {"ID_Barang", "Nama_Barang", "Tanggal_Pemakaian", "Jumlah_Digunakan", "Digunakan_Oleh"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable PbarangTable = new JTable(model);
        PbarangTable .setFont(new Font("Arial", Font.PLAIN, 12));
        PbarangTable .setRowHeight(25);
        PbarangTable .setFillsViewportHeight(true);
        PbarangTable .setShowVerticalLines(false);
        PbarangTable .setIntercellSpacing(new Dimension(0, 0));
        PbarangTable .getTableHeader().setReorderingAllowed(false);

        // Ambil data dari database
        try {
            Connection conn = new koneksi().connect();
            String sql = "SELECT * FROM pemakaianbarang";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("IdPemakaian"),
                    rs.getString("Id_Barang"),
                    rs.getString("NamaBarang"),
                    rs.getString("TanggalPemakaian"),
                    rs.getString("Jumlah"),
                    rs.getString("TDigunakanOleh"),
                   
                };
                model.addRow(row);
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
        JScrollPane scrollPane = new JScrollPane(PbarangTable );

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        JButton addBtn = new JButton("Tambah");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Hapus");

        
        // Aksi tombol Tambah
        addBtn.addActionListener(e -> {
          Pemakaian_Barang  form = new Pemakaian_Barang (); 
            form.setVisible(true);
        });

        editBtn.addActionListener(e -> {
            int selectedRow = PbarangTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }

            String IdPemakaian = model.getValueAt(selectedRow, 0).toString(); // ID
            String Id_Barang = model.getValueAt(selectedRow, 1).toString();   // ID Barang
            String NamaBarang = model.getValueAt(selectedRow, 2).toString();  // Nama Barang
            String TanggalPemakaian = model.getValueAt(selectedRow, 3).toString(); // Tanggal
            String Jumlah = model.getValueAt(selectedRow, 4).toString();      // Jumlah
            String DigunakanOleh = model.getValueAt(selectedRow, 5).toString(); // Digunakan oleh

            
            Pemakaian_Barang form = new Pemakaian_Barang(); 
            form.setEditMode(true); // mode edit
            form.setData(IdPemakaian, Id_Barang, NamaBarang, TanggalPemakaian, Jumlah,  DigunakanOleh);
            form.setVisible(true);
        });
        
        deleteBtn.addActionListener(e -> {
            int selectedRow = PbarangTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM barang WHERE IdPemakaian = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id);
                    stmt.executeUpdate();
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow); // Hapus dari tabel
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });
        
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
}

private void createPESANANPEMBELIANContent() {
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title Panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(backgroundColor);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel("PO");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(primaryColor);
        titlePanel.add(titleLabel, BorderLayout.WEST);

        // Kolom tabel
        String[] columns = {"ID_Pesanan", "Id_Supplier", "Id_Barang", "Tanggal_Pemesanan", "Jenis_Transaksi", "Jumlah_Beli", "Total_Harga","StatusPo"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable PoTable = new JTable(model);
        PoTable .setFont(new Font("Arial", Font.PLAIN, 12));
        PoTable  .setRowHeight(25);
        PoTable  .setFillsViewportHeight(true);
        PoTable  .setShowVerticalLines(false);
        PoTable  .setIntercellSpacing(new Dimension(0, 0));
        PoTable  .getTableHeader().setReorderingAllowed(false);

        // Ambil data dari database
        try {
            Connection conn = new koneksi().connect();
            String sql = "SELECT * FROM po";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("IdPo"),
                    rs.getString("IdSupplier"),
                    rs.getString("IdBarang"),
                    rs.getString("TanggalPemesanan"),
                    rs.getString("JenisTransaksi"),
                    rs.getString("TotalHarga"),
                    rs.getString("StatusPo"),
                   
                };
                model.addRow(row);
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage());
        }
        JScrollPane scrollPane = new JScrollPane(PoTable );

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(backgroundColor);

        JButton addBtn = new JButton("Tambah");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Hapus");

        
        // Aksi tombol Tambah
        addBtn.addActionListener(e -> {
         PO form = new PO (); 
            form.setVisible(true);
        });

        editBtn.addActionListener(e -> {
            int selectedRow = PoTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit.");
                return;
            }

            String IdPesanan = model.getValueAt(selectedRow, 0).toString();
            String IdSupplier = model.getValueAt(selectedRow, 0).toString();
            String IdBarang = model.getValueAt(selectedRow, 1).toString();   
            String TanggalPemesanan = model.getValueAt(selectedRow, 2).toString();  
            String JenisTransaksi = model.getValueAt(selectedRow, 3).toString(); 
            String JumlahBeli = model.getValueAt(selectedRow, 3).toString(); 
            String TotalHarga = model.getValueAt(selectedRow, 4).toString();      
            String StatusPo = model.getValueAt(selectedRow, 5).toString(); 

            
            PO form = new PO (); 
            form.setEditMode(true); // mode edit
            form.setData(IdPesanan, IdSupplier, IdBarang, TanggalPemesanan, JenisTransaksi,  JumlahBeli, TotalHarga, StatusPo );
            form.setVisible(true);
        });
        
        deleteBtn.addActionListener(e -> {
            int selectedRow = PoTable .getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus.");
                return;
            }

            String id = model.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(null, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = new koneksi().connect();
                    String sql = "DELETE FROM pemakaianbarang WHERE IdPo = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, id);
                    stmt.executeUpdate();
                    stmt.close();
                    conn.close();

                    model.removeRow(selectedRow); // Hapus dari tabel
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
                }
            }
        });
        
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
}

private JPanel createRoomSection(String title, String[] facilities) {
        JPanel sectionPanel = new JPanel(new BorderLayout());
        sectionPanel.setBackground(Color.WHITE);
        sectionPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1), 
            title, 
            0, 
            0, 
            new Font("Arial", Font.BOLD, 16)
        ));

        // Left side - Image placeholder
        JPanel imagePanel = new JPanel();
        imagePanel.setBackground(new Color(220, 220, 220));
        imagePanel.setPreferredSize(new Dimension(150, 120));
        imagePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel imageLabel = new JLabel("🖼️", SwingConstants.CENTER);
        imageLabel.setFont(new Font("Arial", Font.PLAIN, 40));
        imageLabel.setForeground(Color.GRAY);
        imagePanel.add(imageLabel);

        // Center - Facilities list
        JPanel facilitiesPanel = new JPanel();
        facilitiesPanel.setLayout(new BoxLayout(facilitiesPanel, BoxLayout.Y_AXIS));
        facilitiesPanel.setBackground(Color.WHITE);
        facilitiesPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 10));

        JLabel facilitiesLabel = new JLabel("FACILITIES:");
        facilitiesLabel.setFont(new Font("Arial", Font.BOLD, 12));
        facilitiesPanel.add(facilitiesLabel);
        facilitiesPanel.add(Box.createRigidArea(new Dimension(0, 5)));

        for (String facility : facilities) {
            JLabel facilityLabel = new JLabel("• " + facility);
            facilityLabel.setFont(new Font("Arial", Font.PLAIN, 10));
            facilitiesPanel.add(facilityLabel);
        }

        // Right side - Book button
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.WHITE);
        
        JButton bookButton = new JButton("BOOK NOW");
        bookButton.setBackground(primaryColor);
        bookButton.setForeground(Color.WHITE);
        bookButton.setPreferredSize(new Dimension(100, 35));
        bookButton.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        bookButton.setFont(new Font("Arial", Font.BOLD, 12));
        bookButton.setFocusPainted(false);
               
        bookButton.addActionListener(e -> {
            Booking form = new Booking();
            form.setVisible(true);
            form.setOnDataSaved(() -> {
                updateContent("BOOKING"); 
            });
        });
        
        buttonPanel.add(bookButton);

        sectionPanel.add(imagePanel, BorderLayout.WEST);
        sectionPanel.add(facilitiesPanel, BorderLayout.CENTER);
        sectionPanel.add(buttonPanel, BorderLayout.EAST);

        return sectionPanel;
    }

    private String[] getRomanticFacilities() {
        return new String[] {
            "Pemandangan GUNUNG BATUR",
            "Tempat tidur Queen",
            "AC",
            "Breakfast untuk 2 orang",
            "Lampu ambient romantic",
            "Kamar mandi dalam 1 air panas",
            "Mini Bar",
            "Wi-fi gratis",
            "Amenities lengkap (handuk, sabun, shampoo)",
            "Speaker bluetooth portable",
            "Dekorasi honeymoon (optional)"
        };
    }

    private String[] getFamilyFacilities() {
        return new String[] {
            "2 Tempat tidur (Queen + Twin)",
            "Meja makan mini indoor",
            "AC",
            "Kamar mandi dalam + air panas",
            "Area bermain anak",
            "Private terrace / halaman",
            "Breakfast untuk 4 orang",
            "Hi-speed wifi",
            "Lemari besar & gantungan baju",
            "Kulkas besar kain keluarga",
            "Alat BBQ (sharing)",
            "Wi-fi gratis"
        };
    }

    private String[] getFriendFacilities() {
        return new String[] {
            "Tempat tidur Queen",
            "Meja nongkrong indoor/outdoor",
            "Kipas angin",
            "Banyak colokan listrik & USB",
            "Akses games (uno, kartu, catur main)",
            "Facilities BBQ (sharing)",
            "Snack welcome pack",
            "Wi-fi gratis",
            "Santai & tempat nongkrong",
            "Gantungan baju & rak sepatu"
        };
    }
    
    

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }
}