/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Tampilan;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.DriverManager;
import java.util.Date;
import java.text.ParseException;

import koneksi.koneksi;
/**
 *
 * @author Microsoft
 */
public class Payment extends javax.swing.JFrame {
            Connection conn;
            Statement stm;
    /**
     * Creates new form Payment
     */
    public Payment() {
        initComponents();
        //panggil koneksi
       koneksi koneksi = new koneksi();
       this.conn = koneksi.connect();
      // tampilkanData();
       
        try {
            stm = conn.createStatement(); // sukses kalau conn tidak null
            //tampilkanData(); // ← setelah statement siap
        } catch (Exception e) {
            System.out.println("Gagal membuat statement: " + e.getMessage());
        }
    }
    
    private boolean isEditMode = false;

    public void setEditMode(boolean editMode) {
        this.isEditMode = editMode;
    }
    
    
public void setData(String idPayment, String idBooking, String NamaPelanggan, String CheckinTime, String CheckoutTime, String Denda, String Total, String Status) {
    txtid.setText(idPayment);
    txtidbooking.setText(idBooking);
    txtnama.setText(NamaPelanggan);
    
    // Format tanggal yang sesuai dengan data kamu
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // atau "dd-MM-yyyy" sesuai format data kamu

    try {
        Date checkinDate = sdf.parse(CheckinTime);
        Date checkoutDate = sdf.parse(CheckoutTime);
        txtjcalender1.setDate(checkinDate);
        txtjcalender2.setDate(checkoutDate);
    } catch (ParseException e) {
        JOptionPane.showMessageDialog(null, "Format tanggal salah: " + e.getMessage());
    }

    txtdenda.setText(Denda);
    txttotal.setText(Total);
    txtstatus.setSelectedItem(Status);
}
    
//public void tampilkanData() {
//    // Buat model tabel baru
//    DefaultTableModel model = new DefaultTableModel();
//
//    // Tambahkan kolom-kolom ke model tabel
//    model.addColumn("IdPayment");
//    model.addColumn("IdBooking");
//    model.addColumn("NamaPelanggan");
//    model.addColumn("CheckinTime");
//    model.addColumn("CheckoutTime");
//    model.addColumn("Denda");
//    model.addColumn("TotalPembayaran");
//    model.addColumn("StatusPembayaran");
//
//    // Set model ke JTable
//    Tabelpembayaran.setModel(model);
//
//    // Ambil data dari database dan masukkan ke tabel
//    try {
//        String sql = "SELECT * FROM payment";
//        Statement stmt = conn.createStatement();
//        ResultSet rs = stmt.executeQuery(sql);
//
//        NumberFormat nf = NumberFormat.getInstance(new Locale("id", "ID"));
//while (rs.next()) {
//    int denda = rs.getInt("Denda");
//    int total = rs.getInt("TotalPembayaran");
//
//    String formattedDenda = denda == 0 ? "-" : nf.format(denda);
//    String formattedTotal = nf.format(total);
//
//    Object[] row = {
//        rs.getString("IdPayment"),
//        rs.getString("IdBooking"),
//        rs.getString("NamaPelanggan"),
//        rs.getString("CheckinTime"),
//        rs.getString("CheckoutTime"),
//        formattedDenda,
//        formattedTotal,
//        rs.getString("StatusPembayaran")
//    };
//    model.addRow(row);
//}
//        // Tutup koneksi
//        rs.close();
//        stmt.close();
//
//    } catch (SQLException e) {
//        JOptionPane.showMessageDialog(null, "Gagal menampilkan data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//    }
//}
//
//
//void TabelpembayaranMouseCli1Clicked(java.awt.event.MouseEvent evt) {
//    int baris = Tabelpembayaran.getSelectedRow();
//    if (baris != -1) {
//        String IdPayment = Tabelpembayaran.getValueAt(baris, 0).toString();
//        String IdBooking = Tabelpembayaran.getValueAt(baris, 1).toString();
//        String NamaPelanggan = Tabelpembayaran.getValueAt(baris, 2).toString();
//        String CheckinTime= Tabelpembayaran.getValueAt(baris, 3).toString();
//        String CheckoutTime = Tabelpembayaran.getValueAt(baris, 4).toString();
//        String Denda = Tabelpembayaran.getValueAt(baris, 5).toString();
//        String TotalPembayaran = Tabelpembayaran.getValueAt(baris, 6).toString();
//        String StatusPembayaran = Tabelpembayaran.getValueAt(baris, 7).toString();
//
//        // Set nilai ke komponen input
//        txtid.setText(IdPayment);
//        txtidbooking.setText(IdBooking);
//        txtnama.setText(NamaPelanggan);
//
//        // Konversi tanggal string ke java.util.Date
//        try {
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//            java.util.Date date1 = sdf.parse(CheckinTime);
//            java.util.Date date2 = sdf.parse(CheckoutTime);
//            txtjcalender1.setDate(date1);
//            txtjcalender2.setDate(date2);
//        } catch (Exception e) {
//            e.printStackTrace(); // Bisa diganti alert kalau mau
//        }
//
//        // Hilangkan titik pada angka agar bisa diolah lagi
//        txtdenda.setText(Denda.equals("-") ? "" : Denda.replace(".", ""));
//        txttotal.setText(TotalPembayaran.replace(".", ""));
//    }
//}

  private void bersihkanTextbox() {
    // Mengatur nilai setiap JTextField menjadi kosong
    txtid.setText("");
    txtidbooking.setText(""); 
    txtnama.setText("");
    txtjcalender1.setDate(null);
    txtjcalender2.setDate(null);
    txtdenda.setText("");
    txttotal.setText("");
    txtstatus.addItem("");
}
  

//  private void loadData() {
//    DefaultTableModel model = (DefaultTableModel) Tabelpembayaran.getModel();
//    model.setRowCount(0); // bersihkan tabel
//
//    try {
//        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/glamping", "root", "");
//        String sql = "SELECT * FROM payment";
//        Statement stmt = conn.createStatement();
//        ResultSet rs = stmt.executeQuery(sql);
//
//        while (rs.next()) {
//            String IdPayment= rs.getString("IdPayment");
//            String IdBooking = rs.getString("IdBooking");
//            String NamaPelanggan = rs.getString("NamaPelanggan");
//            String CheckinTime = rs.getString("CheckinTime");
//            String ChecoutTime= rs.getString("CheckoutTime");
//            String Denda = rs.getString("Denda");
//            String Total= rs.getString("TotalPembayaran");
//            String StatusPembayaran= rs.getString("StatusPembayaran");
//
//
//           model.addRow(new Object[]{IdPayment, IdBooking, NamaPelanggan, CheckinTime, ChecoutTime, Denda, Total, StatusPembayaran});
//
//        }
//
//        rs.close();
//        stmt.close();
//        conn.close();
//
//    } catch (Exception e) {
//        JOptionPane.showMessageDialog(null, "Gagal memuat data: " + e.getMessage());
//    }
//}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtidbooking = new javax.swing.JTextField();
        txtid = new javax.swing.JTextField();
        txtnama = new javax.swing.JTextField();
        txtdenda = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txttotal = new javax.swing.JTextField();
        txtstatus = new javax.swing.JComboBox<>();
        btnsimpan = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        btnbatal = new javax.swing.JButton();
        btnbersihkan = new javax.swing.JButton();
        txtjcalender1 = new com.toedter.calendar.JDateChooser();
        txtjcalender2 = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel1.setText("PEMBAYARAN");

        jLabel2.setText("ID Pembayaran");

        jLabel3.setText("Nama");

        jLabel4.setText("Chek-in (Time)");

        jLabel5.setText("Denda");

        jLabel6.setText("Chek-out(Time)");

        jLabel7.setText("Status Payment");

        txtidbooking.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtidbookingFocusLost(evt);
            }
        });

        jLabel8.setText("Total Pembayaran");

        txttotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttotalActionPerformed(evt);
            }
        });

        txtstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunas", "Deposit Paid", "Refuned" }));
        txtstatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtstatusActionPerformed(evt);
            }
        });

        btnsimpan.setText("Simpan");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });

        btnhapus.setText("Hapus");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });

        jLabel9.setText("ID Booking");

        btnbatal.setText("Batal");
        btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbatalActionPerformed(evt);
            }
        });

        btnbersihkan.setText("Bersihkan");
        btnbersihkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbersihkanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(108, 108, 108)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtidbooking)
                                    .addComponent(txtnama, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtjcalender1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtdenda, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txttotal, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtid)
                                    .addComponent(txtjcalender2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(189, 189, 189)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtstatus, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btnsimpan)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnbersihkan)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnhapus)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnbatal)))))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtidbooking, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9))))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(15, 15, 15)
                        .addComponent(jLabel4))
                    .addComponent(txtjcalender1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtjcalender2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtdenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8)
                    .addComponent(txttotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnhapus)
                    .addComponent(btnsimpan)
                    .addComponent(btnbatal)
                    .addComponent(btnbersihkan))
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 135, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(88, 88, 88))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(298, 298, 298))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(26, 26, 26)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        //BUTTON SIMPAN
try {
    String IdPayment = txtid.getText();
    String IdBooking = txtidbooking.getText();
    String NamaPelanggan = txtnama.getText();

    // Ambil tanggal dari JDateChooser
    java.util.Date tglCheckin = txtjcalender1.getDate();
    java.util.Date tglCheckout = txtjcalender2.getDate();

    // Format tanggal jadi string (misalnya: yyyy-MM-dd)
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String CheckinTime = sdf.format(tglCheckin);
    String CheckoutTime = sdf.format(tglCheckout);

    // Tangani Denda
    String DendaInput = txtdenda.getText().trim();
    int denda = 0;

    if (DendaInput.equals("-") || DendaInput.isEmpty()) {
        denda = 0;
    } else {
        try {
            // Hapus titik jika ada format ribuan
            DendaInput = DendaInput.replace(".", "").replace(",", "").trim();

            // Validasi angka
            if (!DendaInput.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "Denda harus berupa angka!");
                return;
            }

            denda = Integer.parseInt(DendaInput);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Format angka denda tidak valid!");
            return;
        }
    }

    // Tangani Total Pembayaran
    String totalInput = txttotal.getText().trim();
    int TotalPembayaran;

    if (totalInput.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Total pembayaran tidak boleh kosong!");
        return;
    } else {
        totalInput = totalInput.replace(".", "").replace(",", "").trim();

        if (!totalInput.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "Total pembayaran harus berupa angka!");
            return;
        }

        TotalPembayaran = Integer.parseInt(totalInput);
    }

    // Status
    String StatusPembayaran = txtstatus.getSelectedItem().toString();

    // SQL Statement
    String sql = "INSERT INTO pembayaran (id_pembayaran, id_booking, nama, waktu_chekin, waktu_chekout, denda, TotalPembayaran, StatusPembayaran) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setString(1, IdPayment);
    stmt.setString(2, IdBooking);
    stmt.setString(3, NamaPelanggan);
    stmt.setString(4,CheckinTime);
    stmt.setString(5, CheckoutTime);
    stmt.setInt(6, denda);
    stmt.setInt(7, TotalPembayaran);
    stmt.setString(8, StatusPembayaran);

    int rowsInserted = stmt.executeUpdate();
    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan");
        //tampilkanData();
    }
} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Error SQL: " + e.getMessage());
} catch (NullPointerException e) {
    JOptionPane.showMessageDialog(null, "Tanggal tidak boleh kosong!");
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Format angka tidak valid!");
}
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
         // BUTOON HAPUS                                      
    String IdPayment = txtid.getText();    
    if (IdPayment.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Masukkan id pembayaran untuk menghapus data.");
        return;
    }
    // Query SQL untuk menghapus data berdasarkan NIM
    String sql = "DELETE FROM pembayaran WHERE id_pembayaran = ?";
    try {
            PreparedStatement stmt = conn.prepareStatement(sql);
             stmt.setString(1, IdPayment);
        // Eksekusi query
        int rowsDeleted = stmt.executeUpdate();
        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
            bersihkanTextbox(); // Bersihkan textbox setelah hapus
            //tampilkanData();    // Tampilkan data terupdate di tabel
        } else {
            JOptionPane.showMessageDialog(null, "Data dengan ID PAYMENT " + IdPayment + " tidak ditemukan.");
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Gagal menghapus data: " + ex.getMessage());
    }
    }//GEN-LAST:event_btnhapusActionPerformed

    private void txtstatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtstatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstatusActionPerformed

    private void txttotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttotalActionPerformed

    private void btnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbatalActionPerformed
         // BUTTON KELUAR
        int pilihan = JOptionPane.showConfirmDialog(null, "Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", JOptionPane.YES_NO_OPTION);
        if (pilihan == JOptionPane.YES_OPTION) {
            System.exit(0); // Menutup aplikasi jika pengguna memilih "Yes"
        } 
    }//GEN-LAST:event_btnbatalActionPerformed

    private void btnbersihkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbersihkanActionPerformed
         // BUTTON BERSIHKAN
             bersihkanTextbox();
    }//GEN-LAST:event_btnbersihkanActionPerformed

    private void txtidbookingFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtidbookingFocusLost
        // fokuslost
       String IdBookingText = txtidbooking.getText().trim(); 

if (!IdBookingText.isEmpty()) {
    try {
        int IdBooking = Integer.parseInt(IdBookingText);
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/glamping", "root", "");

        String sql = "SELECT c.NamaPelanggan FROM booking b JOIN pelanggan c ON b.idPelanggan = c.idPelanggan WHERE b.IdBooking = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, IdBooking);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            txtnama.setText(rs.getString("NamaPelanggan"));
        } else {
            txtnama.setText("");
            JOptionPane.showMessageDialog(null, "ID Booking tidak ditemukan.");
        }

        rs.close();
        ps.close();
        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
    }
}
    }//GEN-LAST:event_txtidbookingFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Payment().setVisible(true);
            }
        });
       }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbatal;
    private javax.swing.JButton btnbersihkan;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnsimpan;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtdenda;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtidbooking;
    private com.toedter.calendar.JDateChooser txtjcalender1;
    private com.toedter.calendar.JDateChooser txtjcalender2;
    private javax.swing.JTextField txtnama;
    private javax.swing.JComboBox<String> txtstatus;
    private javax.swing.JTextField txttotal;
    // End of variables declaration//GEN-END:variables
}
