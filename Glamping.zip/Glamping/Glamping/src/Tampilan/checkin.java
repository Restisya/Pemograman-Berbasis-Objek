/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Tampilan;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import koneksi.koneksi;

/**
 *
 * @author AYU
 */
public class checkin extends javax.swing.JFrame {

    /**
     * Creates new form checkin
     */
    Connection conn;
    public checkin() {
        initComponents();
        koneksi koneksi1 = new koneksi();
        conn = koneksi1.connect();
        loadBookingToComboBox(); // urutan diperbaiki
        loadPelangganToComboBox("-");
                    // Listener untuk filter pelanggan sesuai booking
    pilihBooking.addActionListener(e -> {
            ComboItem selected = (ComboItem) pilihBooking.getSelectedItem();
            if (selected != null) {
                String idBooking = selected.getId();
                loadPelangganToComboBox(idBooking);

                if (!idBooking.equals("-")) {
                    isiTanggalDariBooking(idBooking);
                } else {
                    tglin.setDate(null);
                    tglout.setDate(null);
                }
            }
        });
}

    private Runnable onDataSaved;
    public void setOnDataSaved(Runnable callback) {
        this.onDataSaved = callback;
    }
    //untuk tombol simpan nantinya, edit atau tambah data
    private boolean isEditMode = false;
    public void setEditMode(boolean editMode) {
        this.isEditMode = editMode;
    }
    

    public class ComboItem {
        private String id;
        private String label;

        public ComboItem(String id, String label) {
            this.id = id;
            this.label = label;
        }

        public String getId() {
            return id;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    private void isiTanggalDariBooking(String idBooking) {
        String sql = "SELECT TanggalCheckin, TanggalCheckout FROM booking WHERE IdBooking = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, idBooking);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date tglCheckin = sdf.parse(rs.getString("TanggalCheckin"));
                Date tglCheckout = sdf.parse(rs.getString("TanggalCheckout"));
                tglin.setDate(tglCheckin);
                tglout.setDate(tglCheckout);
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mengambil tanggal dari booking: " + e.getMessage());
        }
    }

    
    
    public void loadPelangganToComboBox(String idBooking) {
        pilihPelanggan.removeAllItems();

        String sql;
        if (idBooking == null || idBooking.equals("-")) {
            sql = "SELECT IdPelanggan, NamaPelanggan FROM pelanggan";
        } else {
            sql = "SELECT p.IdPelanggan, p.NamaPelanggan FROM pelanggan p JOIN booking b ON p.IdPelanggan = b.IdPelanggan WHERE b.IdBooking = ?";
        }

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            if (!idBooking.equals("-")) {
                stmt.setString(1, idBooking);
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                pilihPelanggan.addItem(new ComboItem(rs.getString("IdPelanggan"), rs.getString("NamaPelanggan")));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat pelanggan: " + e.getMessage());
        }
    }

    // ========== Load Booking ==========
    public void loadBookingToComboBox() {
        pilihBooking.removeAllItems();
        pilihBooking.addItem(new ComboItem("-", "-")); // pilihan kosong

        try {
            String sql = "SELECT IdBooking FROM booking";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                pilihBooking.addItem(new ComboItem(rs.getString("IdBooking"), rs.getString("IdBooking")));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat booking: " + e.getMessage());
        }
    }
    
    // ========== Set Data Saat Edit ==========
    public void setData(String pelangganId, String bookingId, String tglcheckin, String tglcheckout, String payment) {
        pilihBooking.setSelectedItem(new ComboItem(bookingId != null ? bookingId : "-", ""));
        pilihPelanggan.setSelectedItem(new ComboItem(pelangganId, ""));
        pilihPayment.setSelectedItem(payment);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            tglin.setDate(sdf.parse(tglcheckin));
            tglout.setDate(sdf.parse(tglcheckout));
        } catch (ParseException e) {
            tglin.setDate(null);
            tglout.setDate(null);
        }
    }
    
     private void simpanDataBaru() {
        ComboItem pelanggan = (ComboItem) pilihPelanggan.getSelectedItem();
        ComboItem booking = (ComboItem) pilihBooking.getSelectedItem();
        String payment = pilihPayment.getSelectedItem().toString();

        if (pelanggan == null) {
            JOptionPane.showMessageDialog(this, "Pilih pelanggan dan booking terlebih dahulu.");
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tglcheckin, tglcheckout;

        try {
            tglcheckin = sdf.format(tglin.getDate());
            tglcheckout = sdf.format(tglout.getDate());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tanggal belum lengkap atau salah.");
            return;
        }

        try {
            String sql = "INSERT INTO checkin (IdPelanggan, IdBooking, TanggalCheckin, TanggalCheckout, Payment) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, pelanggan.getId());
            
            
            // IdBooking bisa null jika "-"
            if (booking == null || booking.getId().equals("-")) {
                stmt.setNull(2, java.sql.Types.VARCHAR); // simpan sebagai NULL
            } else {
                stmt.setString(2, booking.getId());
            }
            
            stmt.setString(3, tglcheckin);
            stmt.setString(4, tglcheckout);
            stmt.setString(5, payment);

            int result = stmt.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
                dispose();
                if (onDataSaved != null) onDataSaved.run();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan data: " + e.getMessage());
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jSlider1 = new javax.swing.JSlider();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pilihPayment = new javax.swing.JComboBox<>();
        pilihPelanggan = new javax.swing.JComboBox<>();
        btnSimpan = new javax.swing.JButton();
        btnBatal = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        tglin = new com.toedter.calendar.JDateChooser();
        tglout = new com.toedter.calendar.JDateChooser();
        pilihBooking = new javax.swing.JComboBox<>();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 20)); // NOI18N
        jLabel1.setText("TAMBAH CHECK IN");

        jLabel2.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel2.setText("ID PELANGGAN");

        jLabel3.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel3.setText("CHECK IN");

        jLabel4.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel4.setText("CHECK OUT");

        jLabel5.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel5.setText("PAYMENT");

        pilihPayment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunas", "DP" }));

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        btnBatal.setText("Batal");
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel7.setText("ID BOOKING");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(pilihPelanggan, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jLabel1)))
                        .addGap(2, 2, 2))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(208, 208, 208))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pilihBooking, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tglin, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pilihPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tglout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(126, 126, 126))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBatal)
                                .addGap(18, 18, 18)))
                        .addComponent(btnSimpan)))
                .addContainerGap(125, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(pilihPelanggan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(pilihBooking, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tglin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(tglout, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pilihPayment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBatal)
                    .addComponent(btnSimpan))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        if (isEditMode) { //jika isEditMode TRUE 
//            updateDataBooking(); //maka jalankan fungsi updateData
        } else {
            simpanDataBaru();//jika isEditMode FALSE jalankan method simpanDataBaru
        }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBatalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(checkin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(checkin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(checkin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(checkin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new checkin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JComboBox<ComboItem> pilihBooking;
    private javax.swing.JComboBox<String> pilihPayment;
    private javax.swing.JComboBox<ComboItem> pilihPelanggan;
    private com.toedter.calendar.JDateChooser tglin;
    private com.toedter.calendar.JDateChooser tglout;
    // End of variables declaration//GEN-END:variables
}
